package com.example.projeto2;

        import androidx.appcompat.app.AppCompatActivity;

        import android.os.Bundle;

public class ActEmail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_email);
    }
}
