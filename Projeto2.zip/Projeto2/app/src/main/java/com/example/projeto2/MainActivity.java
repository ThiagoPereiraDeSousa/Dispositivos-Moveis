package com.example.projeto2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button button1, button2, button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Agenda de Contatos");

        button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(this);

        button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(this);

        button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(this);
    }

    public void onClick(View v) {
        Class classe = null;
        switch (v.getId()){

            case R.id.button1: classe = Fones.class; break;
            case R.id.button2: classe = Email.class; break;
            case R.id.button3: classe = Sobre.class; break;
        }

        Intent intent = new Intent(getApplicationContext(), classe);
        startActivity(intent);
    }


}
