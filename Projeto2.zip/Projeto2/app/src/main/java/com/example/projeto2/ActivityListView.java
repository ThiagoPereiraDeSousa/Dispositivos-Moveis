package com.example.projeto2;

import android.app.Activity;

public class ActivityListView extends Activity {
}
