package com.example.projeto2;

public class Contatos {
    public Contatos() {
    }

    public Contatos(String id , String nomeContato, String celular, String email, String endereco, String genero) {
        this.id = id;
        this.nomeContato = nomeContato;
        this.celular = celular;
        this.email = email;
        this.endereco = endereco;
        this.genero = genero;

    }

    private String id;
    private String nomeContato;
    private String celular;
    private String email;
    private String endereco;
    private String genero;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNomeContato() {
        return nomeContato;
    }

    public void setNomeContato(String nomeContato) {
        this.nomeContato = nomeContato;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }




}
