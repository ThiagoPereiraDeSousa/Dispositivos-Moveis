package com.example.projeto2;

import android.app.Activity;

public class activity_list_view extends Activity {
}
