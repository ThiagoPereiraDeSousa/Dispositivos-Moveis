package com.example.projeto2;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Fones extends AppCompatActivity {
    private ProgressDialog progressDialog;
    List<Contatos> listContatos = new ArrayList<>();
    final int PERMISSIONS_CALL_PHONE_ID = 1;
    boolean permissions_call_phone_value = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);
        setTitle("Contatos - Lista de telefones");
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, PERMISSIONS_CALL_PHONE_ID);
        } else {
            permissions_call_phone_value = true;
        }
        lerContatos();
    }

    public void lerContatos() {
        if (checkInternetConection()) {
            progressDialog = ProgressDialog.show(this, "", "Obtendo dados");
            new DownloadJson().execute("http://mfpledon.com.br/listadecontatosbck.json");
        } else {
            Toast.makeText(getApplicationContext(), "Sem conexão. Verifique.", Toast.LENGTH_LONG).show();
        }
    }
    public boolean checkInternetConection() {
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        } else {
            return false;
        }
    }

    public void mostrarJSONContatos(String strjson) {
        String data = "";
        try {
            JSONObject objRaiz = new JSONObject(strjson);
            JSONArray jsonArray = objRaiz.optJSONArray("listacontatos");
            JSONObject jsonObject = null;
            for (int i = 0; i < jsonArray.length(); i++) {
                jsonObject = jsonArray.getJSONObject(i);
                String id = jsonObject.optString("id");
                String nomeContato = jsonObject.optString("nomecontato");
                String celular = jsonObject.optString("celular");
                String email = jsonObject.optString("email");
                String genero = jsonObject.optString("genero");
                String endereco = jsonObject.optString("endereco");

                Contatos contatos = new Contatos(id, nomeContato, celular, email, genero, endereco);

                listContatos.add(contatos);
                jsonObject = null;
            }
            final String dados[] = new String[listContatos.size()];
            final String id[] = new String[listContatos.size()];
            for (int i = 0; i < listContatos.size(); i++) {
                Contatos cont = listContatos.get(i);
                dados[i] = cont.getNomeContato() + " / " + cont.getCelular();
                id[i] = cont.getId();
            }

            final ArrayAdapter<String> myadapter = new ArrayAdapter<String>(getApplicationContext(),
                    R.layout.item_list,
                    R.id.item_list,
                    dados);
            ListView lista = (ListView) findViewById(R.id.listview);
            lista.setAdapter(myadapter);
            lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    onClick(parent, view, position, id);
                }
            });
            lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                    mostraDadosDoContato(id[i]);
                    return false;
                }
            });
        } catch (JSONException e) {
            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            progressDialog.dismiss();
        }
    }

    private class DownloadJson extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            // params é um vetor onde params[0] é a URL
            try {
                return downloadJSON(params[0]);
            } catch (IOException e) {
                return "URL inválido";
            }
        }

        // onPostExecute exibe o resultado do AsyncTask
        @Override
        protected void onPostExecute(String result) {
            mostrarJSONContatos(result);
        }

        private String downloadJSON(String myurl) throws IOException {
            InputStream is = null;
            String respostaHttp = "";
            HttpURLConnection conn = null;
            InputStream in = null;
            ByteArrayOutputStream bos = null;
            try {
                URL u = new URL(myurl);
                conn = (HttpURLConnection) u.openConnection();
                conn.setConnectTimeout(7000); // 7 segundos de timeout
                conn.setRequestMethod("GET");
                conn.setDoInput(true);
                conn.connect();
                in = conn.getInputStream();
                bos = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int len;
                while ((len = in.read(buffer)) > 0) {
                    bos.write(buffer, 0, len);
                }
                respostaHttp = bos.toString("UTF-8");
                return respostaHttp;
            } catch (Exception ex) {
                return "URL inválido ou estouro de memória ou...: \n" + ex.getMessage() + "\nmyurl: " + myurl;
            } finally {
                if (in != null) in.close();
            }
        }

    }

    public void onClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        try {
            if (arg2 < 16) {
                if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    String fone = listContatos.get(arg2).getCelular();
                    Uri uri = Uri.parse("tel:" + fone);  //ligar para o número de telefone do contato selecionado
                    Intent it = new Intent(Intent.ACTION_CALL, uri);
                    startActivity(it);
                } else {
                    Toast.makeText(this, "\nAs ligações não foram autorizadas neste aparelho.\n", Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception exx) {
        }
    }

    public void mostraDadosDoContato(String id) {
        for (int i = 0 ; i < listContatos.size(); i++){
            if(listContatos.get(i).getId() == id){
                Toast.makeText(getApplicationContext(), listContatos.get(i).getNomeContato() + ", " + listContatos.get(i).getEmail()
                        + ", " + listContatos.get(i).getEndereco()  + ", " + listContatos.get(i).getGenero() + ", " + listContatos.get(i).getCelular(), Toast.LENGTH_SHORT).show();
            }
        }

    }
}
